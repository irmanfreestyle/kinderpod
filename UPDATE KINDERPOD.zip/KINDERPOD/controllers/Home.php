<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index() {
	    
	    $cat = $this->input->get('cat');
	    
		$data['title'] = 'Home | KinderPod - Improving Intelligence through Stories';	
		$data['content'] = "client/home";		
		
		
		$data['podcasts'] = "";
		$data['cat'] = $cat;
		$this->db->order_by('podcast_id', 'desc');
		if(isset($cat)) {
		    $data['podcasts'] = $this->db->get_where('podcasts', array('podcast_category' => $cat))->result();
		} else {
		    $data['podcasts'] = $this->db->get('podcasts')->result();
		}

		$this->db->order_by('album_id');
		$data['albums'] = $this->db->get('albums')->result();

		foreach($data['podcasts'] as $index=>$podcast) {
			
			$data['podcasts'][$index]->album = "";
			
			foreach($data['albums'] as $idx=>$album) {
				if($album->album_id == $podcast->album_id_fk) {
					$data['podcasts'][$index]->album = $album;
				}
			}
		}

// 		echo json_encode($data['podcasts']); die();
		$this->load->view('client/template', $data);	
	}
}
