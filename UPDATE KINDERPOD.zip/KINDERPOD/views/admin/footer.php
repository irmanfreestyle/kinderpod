<footer class="main-footer">
<strong>Copyright &copy; 2019 </strong>
</footer>