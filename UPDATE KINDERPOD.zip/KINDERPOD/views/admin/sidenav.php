<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
  <li class="">
    <a href="<?php echo base_url() ?>admin">
      <i class="fa fa-dashboard"></i> <span>List Podcast</span>          
    </a>          
  </li>
  <li>
    <a href="<?php echo base_url() ?>admin/pageUpload">
      <i class="fa fa-upload"></i>
      <span>Upload Podcast</span>
    </a>         
  </li>
  <li>
    <a href="<?php echo base_url() ?>admin/pageAlbum">
      <i class="fa fa-music"></i>
      <span>Album</span>
    </a>         
  </!-->
  <li>
    <a href="<?php echo base_url() ?>admin/logout" class="text-red">
      <i class="fa fa-sign-out"></i>
      <span>Logout</span>
    </a>         
  </li>  
</ul>