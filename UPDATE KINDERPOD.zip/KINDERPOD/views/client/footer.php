<style>
    .footer-inner {
        margin: auto;
        width: 700px;
        max-width: 100%;
        display: flex;
    }
</style>

<div class="bg-primary w-100 py-2">
    <div class="footer-inner text-white">
        <p class="pr-3">Follow us on:</p>
        <div>
            <div class="d-flex justify-content-center py-1">
                <i style="font-size:25px" class="fa fa-facebook-square"></i> &thinsp;
                @kinderpod.id
            </div>
            <div class="d-flex justify-content-center py-1">
                <i style="font-size:25px" class="fa fa-instagram"></i> &thinsp;
                @kinderpod.id
            </div>
        </div>
    </div>
</div>